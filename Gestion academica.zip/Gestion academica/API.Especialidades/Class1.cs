﻿namespace API.Especialidades
{
    public class Class1
    {

    }
}
