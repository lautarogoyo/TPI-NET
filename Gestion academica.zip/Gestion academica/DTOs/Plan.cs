﻿namespace DTOs
{
    public class PlanDTO
    {
        public int IDPlan { get; set; }
        public string DescPlan { get; set; }
        public int IDEspecialidad { get; set; }
    }
}
