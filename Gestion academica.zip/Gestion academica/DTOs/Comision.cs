﻿namespace DTOs
{
    public class ComisionDTO
    {
        public int IDComision { get; set; }
        public string Descripcion { get; set; }
        public int AnioEspecialidad { get; set; }
        public int IDPlan { get; set; }
    }
}
