﻿namespace DTOs
{
    public class MateriaDTO
    {
        public int IDMateria { get; set; }
        public string Descripcion { get; set; }
        /*
        public int HSSemanales { get; set; }
        public int HSTotales { get; set; }
        public int IDPlan { get; set; }
        */
    }
}
