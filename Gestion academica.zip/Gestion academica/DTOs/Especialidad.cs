﻿namespace DTOs
{
    public class EspecialidadDTO
    {
        public int IDEspecialidad { get; set; }
        public string Descripcion { get; set; }

    }
}