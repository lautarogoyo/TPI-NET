﻿namespace DATA
{
    public class ProfesorInMemory
    {

    }
}
